export const enum Cache_Key {
	Token = "gw-root-token",
	RoleOptions = "gw-root-cid-role-list"
}
export const enum StorageType {
	LOCAL = "local",
	SESSION = "session"
}
