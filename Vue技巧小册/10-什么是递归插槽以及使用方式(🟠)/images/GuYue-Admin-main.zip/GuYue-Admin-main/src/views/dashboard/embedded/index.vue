<template>
	<div class="card content-box">
		<iframe src="https://www.antdv.com/components/overview-cn" frameborder="0" class="full-iframe"></iframe>
	</div>
</template>

<script setup lang="ts" name="embedded"></script>

<style scoped lang="less">
@import url("./index.less");
</style>
