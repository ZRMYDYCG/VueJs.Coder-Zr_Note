<template>
	<div class="card content-box">
		<a-alert
			class="mb-20px w-100"
			message="Unocss🍇🍇"
			description="示例: <div class='text-24px text-primary'>我是unocss</div>"
			type="info"
		/>
		<div class="text-24px text-primary">我是unocss</div>
	</div>
</template>
