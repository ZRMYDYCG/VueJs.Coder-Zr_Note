<template>
	<div class="footer flx-center">
		<a href="https://gitee.com/Y_lao" target="_blank"> 2023 © GuYue-Admin By laoy0702@163.com. </a>
	</div>
</template>

<script setup lang="ts"></script>

<style scoped lang="less">
@import url("./index.less");
</style>
